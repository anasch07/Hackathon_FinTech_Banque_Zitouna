
export default {
    apiBaseUrl: 'http://localhost:5000/api',
  };
